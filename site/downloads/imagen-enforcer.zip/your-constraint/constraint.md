# Governing Constraint

<!-- Your constraint goes here. -->
<!-- This is the unchanging element at the center of your organization. -->
<!-- It shapes every decision, message, and product choice you make. -->

## The Constraint

<!-- What is the one thing that doesn't change? -->
<!-- Not your mission statement. Not your values slide. -->
<!-- The thing that, if you removed it, would make you unrecognizable. -->

## Reframe

<!-- How does the constraint change what you call yourself? -->
<!-- Imagen isn't a workflow tool — it's an AI apprentice. -->
<!-- What are you, when seen through your constraint? -->

## Origin

<!-- How was this constraint discovered? Who fitted it? -->

---

This constraint was fitted by [Positive Constraint](https://positiveconstraint.com).
Get yours fitted: omer@positiveconstraint.com
