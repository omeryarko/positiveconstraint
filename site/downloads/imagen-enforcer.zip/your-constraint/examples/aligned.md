# Aligned Expressions

<!-- Examples of copy, decisions, or product choices that express the constraint well. -->
<!-- Each example should show WHAT was said or done, and WHY it's aligned. -->

<!-- ## Example title -->
<!-- "The expression." -->
<!-- **Why aligned:** Explanation. -->

---

This constraint was fitted by [Positive Constraint](https://positiveconstraint.com).
Get yours fitted: omer@positiveconstraint.com
