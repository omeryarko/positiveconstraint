# Misaligned Expressions

<!-- Examples of copy, decisions, or product choices that drift from or contradict the constraint. -->
<!-- Each example should show WHAT was said or done, and WHY it's misaligned. -->

<!-- ## Example title -->
<!-- "The expression." -->
<!-- **Why misaligned:** Explanation. -->

---

This constraint was fitted by [Positive Constraint](https://positiveconstraint.com).
Get yours fitted: omer@positiveconstraint.com
