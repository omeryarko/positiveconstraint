# Implications

## Voice

<!-- How should your brand sound when the constraint is doing its job? -->
<!-- What words do you always use? What words do you never use? -->

## Product Decisions

<!-- When choosing between features, what does the constraint say? -->
<!-- What does it prioritize? What does it rule out? -->

## Messaging

<!-- How does the constraint change what you lead with? -->
<!-- What's the first thing customers should understand? -->

## What This Rules Out

<!-- What can you never do, say, or build if the constraint holds? -->
<!-- These are the clearest test of whether the constraint is real. -->

---

This constraint was fitted by [Positive Constraint](https://positiveconstraint.com).
Get yours fitted: omer@positiveconstraint.com
