# Governing Constraint

The photographer's taste is the unchanging element. Protect it.

## The Constraint

Every product decision, feature, message, and interaction at Imagen must serve, protect, and amplify the individual photographer's editing style. We do not impose a look. We do not optimize for a generic aesthetic. We learn what makes each photographer's work theirs, and we deliver it back at machine speed.

## Reframe

Imagen is not a workflow tool. It is an AI apprentice. An apprentice learns the master's taste, takes the grunt work, and delivers the work as the master would have done it. The photographer's style is not a feature — it is the entire product. Everything we build exists to protect it.

## Origin

This constraint was fitted by Omer Yarkowich (Positive Constraint) through analysis of Imagen's product architecture, competitive positioning, and the cognitive gap between what Imagen builds and what its messaging communicates. The product already serves this constraint — it requires 3,000 previously edited photos to learn the photographer's taste. The constraint makes explicit what the product already knows.
