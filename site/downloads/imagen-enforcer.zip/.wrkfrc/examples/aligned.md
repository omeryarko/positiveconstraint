# Aligned Expressions

## Apprentice framing

"Imagen is your AI apprentice. Upload 3,000 of your edited photos. It learns your taste. From then on, it edits like you — in minutes, not hours."

**Why aligned:** Positions Imagen as the apprentice. The photographer is the master. The taste is the center.

## Taste as product

"You don't sell photos. You sell how your photos feel. Imagen protects that."

**Why aligned:** Names the photographer's real product (style/feeling), then positions Imagen as its protector.

## Speed through the constraint

"A 15-hour editing job, done in 15 minutes. Not our way — your way."

**Why aligned:** Speed claim is grounded in the constraint. Not generic automation. Your editing, faster.

## Competitive differentiation

"Other tools automate your workflow. Imagen learns your taste. That's the difference."

**Why aligned:** Draws the line between category (workflow tools) and Imagen (taste preservation). The constraint IS the differentiator.

## Onboarding as training

"Training your apprentice takes 3,000 photos. After that, it works like you do."

**Why aligned:** Reframes onboarding friction as investment in the apprentice. Makes the 3,000-photo requirement feel valuable, not burdensome.

## The apprentice has a face

"Meet your apprentice. They're eager, they're fast, and they only care about one thing — making your work look like yours."

**Why aligned:** A character you meet, not a feature you configure. Eager and fast are personality traits, not specs. "Your work look like yours" keeps taste at the center.

## The avatar is real

"Your apprentice looks at you from their desk when you open the app. Not a chatbot bubble. A face. Eyes. Someone who's been working on your photos while you were away."

**Why aligned:** Skeuomorphic, human-like. The avatar is a person at a desk, not an interface element. Trust is built through eye contact and presence, not through feature lists.

## Trust exercise

"Your apprentice holds up five photos and says: 'I'm getting better at your golden-hour palette, but these sunset portraits — can you show me how you'd handle the skin tones here?' You teach. It learns. Next batch, it nails them."

**Why aligned:** The interaction is a trust exercise between two people. The apprentice asks, the photographer teaches, the relationship deepens. The photographer's taste is transferred through dialogue, not configuration.

## The apprentice grows

"Your apprentice just processed its 50,000th photo in your style. It's getting better at the tricky ones."

**Why aligned:** Growth is a relationship metric. "In your style" anchors every milestone to the constraint. "The tricky ones" shows the apprentice learning the edges of the photographer's taste.

## Error as relationship

"Your apprentice isn't sure about this batch. Can you show it what you'd do with these five?"

**Why aligned:** Errors become the apprentice asking for guidance, not the system throwing an exception. The photographer stays in the role of master. The interaction deepens the relationship and improves the model.

## Delivery as pride

"Your apprentice finished the Morrison wedding. 847 photos, edited your way. Ready for review."

**Why aligned:** The apprentice presents work like a person would — naming the project, counting the output, claiming it was done the photographer's way. Review, not approval — the apprentice is confident but deferential.
