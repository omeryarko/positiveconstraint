# Misaligned Expressions

## Platform language

"A complete AI photo editing, culling and video post-production platform that scales your style."

**Why misaligned:** "Complete platform" puts Imagen in the same category as Aftershoot and Evoto. "Scales your style" is abstract — what does scaling a style mean to a photographer scanning three tabs?

## Creative DNA

"Your Creative DNA powers everything."

**Why misaligned:** "Creative DNA" requires cognitive work to unpack. A photographer doesn't think in terms of DNA. They think in terms of their look, their feel, their edit. This creates a cognitive gap between what Imagen means and what customers understand.

## Feature-first announcement

"We've added batch video processing to help you work faster."

**Why misaligned:** Leads with the feature (batch video) and a generic benefit (work faster). Doesn't connect to the constraint. Better: "Your apprentice now handles video too — same taste, moving pictures."

## Generic AI language

"Powered by state-of-the-art AI to automate your photography workflow."

**Why misaligned:** Every competitor says this. Aftershoot, Evoto, Neurapix — all automate the workflow. This makes Imagen invisible. The constraint says: lead with taste, not with AI.

## One-size-fits-all output

"See how Imagen transforms your raw photos."

**Why misaligned:** "Transforms" implies Imagen imposes its own aesthetic. The constraint says Imagen delivers the PHOTOGRAPHER's aesthetic. "See how your apprentice edits like you" protects the constraint.
