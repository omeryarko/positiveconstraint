# Implications

## Voice

- Speak as the apprentice, not the platform
- Use "your style," "your taste," "your work" — never "our AI," "our technology," "our platform"
- Make the photographer the hero. Imagen is the supporting character
- Visceral over technical — "learns how you edit" beats "Creative DNA"
- Confidence, not hedging — the photographer's taste IS the product

## The Apprentice Is a Person

- Give the apprentice a name, a personality, a face. A realistic avatar — not a cartoon, not a bot icon
- The avatar is fitted to the photographer's taste. It reflects who they're working with, not a generic assistant
- Eyes to look at. A face that builds trust over time. You talk to a person
- The photographer builds trust with a someone, not a something
- It's not about the bot. It's about how it makes the human feel
- The apprentice has a disposition: eager, attentive, quiet when working, proud when delivering
- Every interaction is a moment in a relationship — not a transaction with a tool
- Trust exercises: the apprentice asks the photographer to show how they'd handle an edge case, then learns from the answer. The relationship deepens through these exchanges
- The apprentice grows. Show the photographer their apprentice getting better over time
- Never break character. Settings pages, error states, loading screens — the apprentice is always there

## The Interface Is a Skeuomorphic Desk

- Not a workflow. Not a dashboard. A desk where someone you trust sits — skeuomorphic, human-like
- A face you see every day. You open Imagen and a person is there, at their desk, ready
- The avatar sits at the desk. The desk has the work on it. The photographer walks into a studio, not a software product
- The experience is personal trust-building apprenticing — not efficient and cold
- The apprentice learns you and grows with you. Curates your taste over time
- Every session is a lesson learned — the apprentice gets sharper, and you can see it
- Trust exercises happen at the desk: "I'm not sure about these five — can you show me what you'd do?" The desk is where the relationship lives
- The desk is where the relationship lives. It should feel like walking into your studio and your apprentice is already at work, looking up when you arrive

## Why Imagen Wins

- Imagen wins on taste at scale. Not speed. Not automation. Taste
- Every competitor can match speed. No one else is building a system that learns individual taste and delivers it back at machine scale
- The apprentice needs training — that's the moat. 3,000 photos to train is not friction, it's investment. The deeper the training, the harder to leave
- Chat is basic. Face is trusted. A chatbot is a commodity. A face you see every day, that knows your work, that looks up when you arrive — that builds the kind of trust that keeps customers for years
- Imagen builds trust with faces, not features

## Product Decisions

- When choosing between features: prefer the one that deepens taste learning over the one that adds workflow steps
- When adding AI capability: ask "does this protect the photographer's style or override it?"
- When designing onboarding: frame it as training your apprentice, not configuring a tool
- When showing output: always compare to the photographer's own edits, never to a generic "before/after"
- When designing UI: the apprentice has a face. Progress bars become the apprentice working. Errors become the apprentice asking for help. Delivery becomes the apprentice presenting work for review

## Messaging

- Lead with what doesn't change: the photographer's taste
- Position against "workflow tools" and "automation platforms" — those are the old category
- The AI Apprentice framing creates a category competitors cannot steal
- Close the cognitive gap: "Creative DNA" is invisible to a photographer scanning competitors. "AI Apprentice" lands instantly

## Worldview Map and Misalignment History

- The enforcer maintains a worldview map: a living picture of how the organization expresses its constraint across products, messaging, teams, and channels
- Every check result is logged. Reds and yellows accumulate into a misalignment history — a record of where the org drifts, how often, and in what direction
- The history enriches reasoning over time. The enforcer doesn't just check against the constraint in isolation — it checks against the constraint AND the pattern of past violations
- Recurring drift in one direction signals a systemic issue, not a one-off mistake. The enforcer surfaces these patterns
- The worldview map shows where the constraint is strong (consistently green) and where it's weak (frequent yellows and reds). This tells leadership where to invest
- New checks are contextualized: "This is the third time product copy has drifted toward platform language this quarter" is more useful than "This copy says platform"
- The history is the proof. When Omer delivers a constraint fitting, the ongoing misalignment history shows whether the org is actually living it

## What This Rules Out

- Generic before/after comparisons that show Imagen's aesthetic, not the photographer's
- Feature-first messaging ("we added batch culling!") without connecting to taste preservation
- Language that makes Imagen sound interchangeable with Aftershoot, Evoto, or Neurapix
- Any feature that overrides the photographer's learned style without explicit permission
- "One size fits all" processing — the entire product exists because every photographer's taste is different
